package com.bookapi;

public record Book (String title) { }