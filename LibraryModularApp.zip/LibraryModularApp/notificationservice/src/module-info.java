module notificationservice {
    exports com.notificationservice;
    uses com.notificationservice.NotificationService;
}
