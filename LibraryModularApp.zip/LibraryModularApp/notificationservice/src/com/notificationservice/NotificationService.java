package com.notificationservice;

public interface NotificationService {
    String getName();
    void sendNotification(String message);
}
