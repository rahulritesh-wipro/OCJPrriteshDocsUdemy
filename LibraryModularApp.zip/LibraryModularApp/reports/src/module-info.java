module reports {
    exports com.reports;
    requires inventory;
}
